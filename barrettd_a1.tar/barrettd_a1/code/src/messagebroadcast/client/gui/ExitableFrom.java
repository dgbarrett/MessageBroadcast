
package messagebroadcast.client.gui;

/*
    Type accepted by the ExitListener constructor.
*/
interface ExitableFrom {
    public void exitGUI();
}
